# Lab Report — Ettercap MITM Simulation

## Objectives
(Brief description of what you aimed to learn)

## Environment
(VMs used, network layout, software versions)

## Steps Taken
(Setup, baseline traffic generation, attack simulation, analysis)

## Observations
- Baseline Traffic:
- Changes Noticed:
- Security Risks Found:

## Mitigation Actions
(Measures tested and their effectiveness)

## Reflection
(Skills gained and lessons learned)
